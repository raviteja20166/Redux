export const COUNTER_INCREMENT = 'counter_increment';
export const COUNTER_DECREMENT = 'counter_decrement';


export const LOGIN = 'login';
export const LOGOUT = 'logout';
