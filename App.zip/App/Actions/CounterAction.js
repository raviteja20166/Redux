import { connect } from 'react-redux';

import * as Actions from './ActionTypes';
import CounterComponent from '../Components/CounterComponent';

const mapStateToProps = (state) => ({
     count: state.counterReducer.count,
     isLoggedIn: state.counterReducer.isLoggedIn
});

const mapDispatchToProps = (dispatch) => ({
    // increment: () => dispatch({type: Actions.COUNTER_INCREMENT}),
    // decrement: () => dispatch({type: Actions.COUNTER_DECREMENT}),
    increment: () => dispatch(
        { type: Actions.LOGIN, name: "", isLoggedIn: true }
    ),
    decrement: () => dispatch(
        { type: Actions.LOGOUT, name: "", isLoggedIn: false }
    ),
    login: (user) => dispatch(
        { type: Actions.LOGIN, name: user.name }
    ),

});

export default connect(mapStateToProps, mapDispatchToProps)(CounterComponent);