import { connect } from 'react-redux';
import * as Actions from '../Actions/ActionTypes';
import LoginComponent from '../Components/LoginComponent';

const mapStateToProps = (state) => ({
    data: state.loginReducer
});

const mapDispatchToProps = (dispatch) => ({
    login: (user) => dispatch(
        {
            type: Actions.LOGIN,
            name: user.name,
            mobile: user.mobile,
            password: user.password
        }
    
    ),
    logout:()=> dispatch(
        {
            type: Actions.LOGOUT,
            
        }
    
    ),
});

export default connect(mapStateToProps, mapDispatchToProps)(LoginComponent);
