import * as Actions from '../Actions/ActionTypes'


let initialState = {
    user: {}, isLoggedIn: false
}
const LoginReducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.LOGIN:
            return {
                ...state,
                isLoggedIn: true,
                user:{
                    name: action.name,
                    mobile: action.mobile,
                    password: action.password
                }
            };
        case Actions.LOGOUT:
            return initialState;
            
        default:
            return state;
    }
}

export default LoginReducer;