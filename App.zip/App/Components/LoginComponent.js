import React from 'react';
import { Button, StyleSheet, Text, TextInput, View } from 'react-native';


class LoginComponent extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            name: '',
            mobile: '',
            password: '',
        }
    }

    render() {

        const data = this.props.data
        // const { name, mobile, password } = this.state
        return (
            <View style={styles.container}>
                {data.isLoggedIn
                    ? <View>
                        <Text style={styles.textStyle}>Name: {data.user.name}</Text>
                        <Text style={styles.textStyle}>MobileNumber:{data.user.mobile} </Text>
                        <Text style={styles.textStyle}>Password: {data.user.password}</Text>


                        <Button
                            onPress={() => { this.props.logout() }}
                            title="Logout"
                            color="#841584"
                        />
                    </View>
                    : <View>

                        <TextInput
                            value={this.state.name}
                            onChangeText={(name) => this.setState({ name })}
                            placeholder={'Name'}
                            style={styles.input}
                        />

                        <TextInput
                            value={this.state.mobileNumber}
                            onChangeText={(mobileNumber) => this.setState({ mobile: mobileNumber })}
                            placeholder={'MobileNumber'}
                            style={styles.input}
                            maxLength={10}
                            keyboardType={"numeric"}
                        />
                        <TextInput
                            value={this.state.password}
                            onChangeText={(password) => this.setState({ password })}
                            placeholder={'Password'}
                            secureTextEntry={true}
                            style={styles.input}
                        />

                        <Button
                            onPress={() => { this.props.login(this.state) }}
                            title="Login"
                            color="#841584"
                        />

                    </View>


                }

            </View>
        );
    }
}

export default LoginComponent

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F5FCFF',
    },
    welcome: {
        fontSize: 20,
        textAlign: 'center',
        margin: 10,
    },
    instructions: {
        textAlign: 'center',
        color: '#333333',
        marginBottom: 5,
    },
    input: {
        height: 44,
        paddingTop: 10,
        borderWidth: 3,
        borderColor: 'black',
        borderRadius: 25,
        marginBottom: 20,
        width: 350

    },
    textStyle: {
        marginTop: 5,
        marginLeft: 5,
        marginRight: 5,
        height: 20,
    }
});